// Backend réel : github.com/70-DIDIER/trustline (Django + DRF).
// Format de verdict normalisé : { score, niveau_risque: "faible"|"suspect"|"eleve", indices, recommandation }.
const API_BASE = "http://127.0.0.1:8000/api";

const cache = new Map(); // domaine -> { verdict, t }
const CACHE_TTL_MS = 60 * 60 * 1000;

const BADGE_COLORS = {
  eleve: "#DC2626",
  suspect: "#D97706",
  faible: "#1E7A4C",
};

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== "complete" || !tab.url || !tab.url.startsWith("http")) return;

  const domaine = new URL(tab.url).hostname;
  const verdict = await verifierDomaine(tab.url);

  chrome.action.setBadgeText({ tabId, text: verdict.niveau_risque === "faible" ? "" : "!" });
  chrome.action.setBadgeBackgroundColor({
    tabId,
    color: BADGE_COLORS[verdict.niveau_risque] || "#6B7086",
  });

  if (verdict.niveau_risque === "eleve") {
    chrome.tabs.sendMessage(tabId, { action: "AFFICHER_BANDEAU", verdict }).catch(() => {});
    chrome.notifications.create({
      type: "basic",
      iconUrl: "assets/icons/128.png",
      title: "⚠️ Site dangereux",
      message: `${domaine} est signalé comme frauduleux. Ne saisissez aucune donnée.`,
    });
  }
});

async function verifierDomaine(url) {
  const domaine = new URL(url).hostname;
  const hit = cache.get(domaine);
  if (hit && Date.now() - hit.t < CACHE_TTL_MS) return hit.v;

  let v;
  try {
    const r = await fetch(`${API_BASE}/liens/analyser/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    v = await r.json();
  } catch (err) {
    // Backend indisponible (offline / pas encore démarré) : on ne casse jamais la navigation.
    v = { niveau_risque: "faible", score: 0, indices: [], recommandation: "" };
  }
  cache.set(domaine, { v, t: Date.now() });
  return v;
}

// Pont pour le popup : analyse à la demande d'un numéro/lien/message collé par l'utilisateur.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "VERIFIER_DOMAINE") {
    verifierDomaine(msg.url).then(sendResponse);
    return true; // réponse asynchrone
  }
  if (msg.action === "ANALYSER_TEXTE") {
    fetch(`${API_BASE}/messages/analyser/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contenu: msg.texte }),
    })
      .then((r) => r.json())
      .then(sendResponse)
      .catch(() =>
        sendResponse({
          niveau_risque: "faible",
          score: 0,
          recommandation: "Backend indisponible — impossible d'analyser pour le moment.",
        })
      );
    return true;
  }
});
