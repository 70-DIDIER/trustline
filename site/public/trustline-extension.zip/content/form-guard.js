// Intercepte la soumission d'un formulaire "sensible" (PIN, mot de passe, carte, OTP...)
// sur un site jugé douteux ou dangereux, et demande confirmation avant l'envoi.
const CHAMPS_SENSIBLES = [
  /pin/i, /code.?secret/i, /mot.?de.?passe/i, /password/i,
  /carte/i, /cvv/i, /otp/i, /numero.?compte/i,
];

function estSensible(form) {
  return [...form.querySelectorAll("input")].some((i) =>
    CHAMPS_SENSIBLES.some((re) => re.test(i.name || "") || re.test(i.id || "") || re.test(i.placeholder || ""))
  );
}

function afficherConfirmation(verdict, onContinue) {
  const box = document.createElement("div");
  box.id = "trustline-form-warning";
  box.style.top = "16px";
  box.style.right = "16px";
  box.innerHTML = `
    <strong>⚠️ TrustLine</strong><br/>
    Ce site n'est pas vérifié (score ${verdict.score ?? "?"}/100) et vous êtes sur le point
    d'envoyer une information sensible.
    <div class="actions">
      <button class="stop">Ne pas envoyer</button>
      <button class="continue">Continuer quand même</button>
    </div>
  `;
  document.body.appendChild(box);
  box.querySelector(".stop").addEventListener("click", () => box.remove());
  box.querySelector(".continue").addEventListener("click", () => {
    box.remove();
    onContinue();
  });
}

function surveillerFormulaires() {
  document.querySelectorAll("form:not([data-trustline-watched])").forEach((form) => {
    form.dataset.trustlineWatched = "1";
    if (!estSensible(form)) return;

    form.addEventListener(
      "submit",
      (e) => {
        e.preventDefault();
        chrome.runtime.sendMessage({ action: "VERIFIER_DOMAINE", url: location.href }, (verdict) => {
          if (verdict && (verdict.niveau_risque === "eleve" || verdict.niveau_risque === "suspect")) {
            afficherConfirmation(verdict, () => form.submit());
          } else {
            form.submit();
          }
        });
      },
      true
    );
  });
}

const observer = new MutationObserver(surveillerFormulaires);
observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
surveillerFormulaires();
