// Affiche le bandeau plein écran quand le background détecte un site dangereux.
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action !== "AFFICHER_BANDEAU") return;
  if (document.getElementById("trustline-banner")) return; // déjà affiché

  const bar = document.createElement("div");
  bar.id = "trustline-banner";
  bar.innerHTML = `
    <span>⚠️ TrustLine — ce site est signalé comme frauduleux (score ${msg.verdict.score ?? "?"}/100). ${msg.verdict.recommandation || "Ne saisissez aucune donnée."}</span>
    <button id="trustline-banner-close">Compris</button>
  `;
  document.documentElement.prepend(bar);
  document.getElementById("trustline-banner-close").addEventListener("click", () => bar.remove());
});
