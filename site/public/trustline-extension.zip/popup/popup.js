const chipEl = document.getElementById("tl-site-verdict");
const domainEl = document.getElementById("tl-site-domain");
const input = document.getElementById("tl-input");
const analyzeBtn = document.getElementById("tl-analyze-btn");
const resultEl = document.getElementById("tl-result");
const reportBtn = document.getElementById("tl-report-btn");

const LABELS = { faible: "Sûr", suspect: "Douteux", eleve: "Dangereux" };

async function chargerSiteActuel() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.startsWith("http")) {
    chipEl.textContent = "Page non analysable";
    return;
  }
  domainEl.textContent = new URL(tab.url).hostname;

  chrome.runtime.sendMessage({ action: "VERIFIER_DOMAINE", url: tab.url }, (verdict) => {
    const niveau = verdict?.niveau_risque || "faible";
    chipEl.textContent = LABELS[niveau] || "Inconnu";
    chipEl.className = `tl-chip tl-chip-${niveau}`;
  });
}

analyzeBtn.addEventListener("click", () => {
  const texte = input.value.trim();
  if (!texte) return;
  resultEl.hidden = false;
  resultEl.textContent = "Analyse en cours…";

  chrome.runtime.sendMessage({ action: "ANALYSER_TEXTE", texte }, (res) => {
    resultEl.textContent = res?.recommandation || "Aucune réponse du serveur — vérifiez que le backend tourne.";
  });
});

reportBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: "http://127.0.0.1:3000/signaler" });
});

chargerSiteActuel();
